<?php
/**
* Modal Form for adding posts in bulk
* Populated via JS function
*/
?>
<div class="nestedpages-modal-backdrop" data-nestedpages-modal="np-bulk-modal"></div>
<div class="nestedpages-modal-content nestedpages" id="np-bulk-modal" data-nestedpages-modal="np-bulk-modal">
	<div class="modal-body new-child"></div>
</div><!-- /.modal -->